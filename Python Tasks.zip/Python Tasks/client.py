# client.py - Chat Client
import socket
import threading

def receive_messages(sock):
    while True:
        try:
            message = sock.recv(1024).decode("utf-8")
            if message:
                print(f"\nServer: {message}")
        except:
            print("Disconnected from server.")
            sock.close()
            break

def main():
    host = "127.0.0.1"
    port = 5555

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((host, port))
    except:
        print("Unable to connect to server.")
        return

    print("Connected to chat server. Type your messages below:\n")
    threading.Thread(target=receive_messages, args=(client,), daemon=True).start()

    while True:
        message = input()
        if message.lower() == 'exit':
            client.close()
            break
        client.send(message.encode("utf-8"))

if __name__ == "__main__":
    main()

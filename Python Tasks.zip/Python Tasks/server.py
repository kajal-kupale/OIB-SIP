# server.py - Chat Server
import socket
import threading

def handle_client(client_socket, addr):
    print(f"[NEW CONNECTION] {addr} connected.")
    while True:
        try:
            message = client_socket.recv(1024).decode("utf-8")
            if message:
                print(f"{addr} says: {message}")
                client_socket.send("Message received!".encode("utf-8"))
            else:
                break
        except:
            break

    print(f"[DISCONNECTED] {addr} disconnected.")
    client_socket.close()

def main():
    host = "127.0.0.1"
    port = 5555
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(1)

    print(f"[STARTED] Server listening on {host}:{port}")
    while True:
        client_socket, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(client_socket, addr))
        thread.start()

if __name__ == "__main__":
    main()

# StopWatch
* Oasis Infobyte Android Development project Stop Watch using xml and java 

# SPLASH SCREEN
<img src="https://i.ibb.co/2srCZQW/stopwatch-splash.png" alt="stopwatch-splash" border="0">

# MAIN ACTIVITY
<img src="https://i.ibb.co/jvjdH4f/stopwatch-main.png" alt="stopwatch-main" border="0">
